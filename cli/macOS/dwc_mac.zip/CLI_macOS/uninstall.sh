#!/bin/sh
# Copyright (c) 2026 ASUSTeK Computer Inc. All rights reserved.
#
# uninstall.sh - Removes dwc from the system environment.
#
# Usage:
#   ./uninstall.sh            # auto-detect what was installed
#   ./uninstall.sh --user     # remove PATH entry from shell rc files
#   ./uninstall.sh --system   # remove /usr/local/bin/dwc and /usr/local/lib/libVCPLibrary.dylib

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

MODE=""
for arg in "$@"; do
    case "$arg" in
        --user)   MODE="user" ;;
        --system) MODE="system" ;;
        *)
            echo "[ERROR] Unknown argument: $arg"
            echo "Usage: $0 [--user | --system]"
            exit 1
            ;;
    esac
done

if [ -z "$MODE" ]; then
    if [ -f "/usr/local/bin/dwc" ]; then
        MODE="system"
    else
        MODE="user"
    fi
fi

# ---------------------------------------------------------------------------
# SYSTEM-WIDE UNINSTALL
# ---------------------------------------------------------------------------
do_system_uninstall() {
    echo "[INFO] Removing dwc from /usr/local/bin and /usr/local/lib ..."

    if [ -f "/usr/local/bin/dwc" ]; then
        sudo rm -f "/usr/local/bin/dwc"
        echo "[OK] Removed /usr/local/bin/dwc"
    else
        echo "[INFO] /usr/local/bin/dwc not found; skipping."
    fi

    if [ -f "/usr/local/lib/libVCPLibrary.dylib" ]; then
        sudo rm -f "/usr/local/lib/libVCPLibrary.dylib"
        echo "[OK] Removed /usr/local/lib/libVCPLibrary.dylib"
    else
        echo "[INFO] /usr/local/lib/libVCPLibrary.dylib not found; skipping."
    fi

    echo ""
    echo "============================================================"
    echo "  SUCCESS: dwc has been uninstalled."
    echo "============================================================"
}

# ---------------------------------------------------------------------------
# USER-LEVEL UNINSTALL
# ---------------------------------------------------------------------------
remove_path_from_rc() {
    RC_FILE="$1"
    [ -f "$RC_FILE" ] || return 0

    TMP_FILE="$(mktemp)"

    # Remove the marker comment and the export PATH line that references this directory.
    # Use grep -v with a temp file + mv for POSIX-safe in-place editing.
    grep -v "# dwc display control CLI" "$RC_FILE" \
        | grep -v "export PATH=\"$SCRIPT_DIR:\$PATH\"" \
        > "$TMP_FILE"

    if diff -q "$RC_FILE" "$TMP_FILE" > /dev/null 2>&1; then
        echo "[INFO] No dwc PATH entry found in $RC_FILE."
        rm -f "$TMP_FILE"
    else
        mv "$TMP_FILE" "$RC_FILE"
        echo "[OK] Removed dwc PATH entry from $RC_FILE."
    fi
}

do_user_uninstall() {
    echo "[INFO] Removing dwc PATH entries ..."

    remove_path_from_rc "$HOME/.zshrc"
    remove_path_from_rc "$HOME/.bash_profile"

    echo ""
    echo "============================================================"
    echo "  SUCCESS: dwc PATH entries have been removed."
    echo "  Restart your terminal for the change to take effect."
    echo "============================================================"
}

case "$MODE" in
    system) do_system_uninstall ;;
    user)   do_user_uninstall ;;
esac

printf "\nPress Enter to close this window..."
read -r _
