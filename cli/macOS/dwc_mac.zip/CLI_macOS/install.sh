#!/bin/sh
# Copyright (c) 2026 ASUSTeK Computer Inc. All rights reserved.
#
# install.sh - Registers dwc in the system environment.
#
# Usage:
#   ./install.sh            # auto-detect mode
#   ./install.sh --user     # user-level install (PATH in ~/.zshrc)
#   ./install.sh --system   # system-wide install (/usr/local/bin, requires sudo)

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DWC_BIN="$SCRIPT_DIR/dwc"
DYLIB="$SCRIPT_DIR/libVCPLibrary.dylib"

[ -f "$DWC_BIN" ] || { echo "[ERROR] dwc not found in '$SCRIPT_DIR'."; echo "        Run install.sh from the same directory as dwc."; exit 1; }
[ -f "$DYLIB"   ] || { echo "[ERROR] libVCPLibrary.dylib not found in '$SCRIPT_DIR'."; exit 1; }

MODE=""
for arg in "$@"; do
    case "$arg" in
        --user)   MODE="user" ;;
        --system) MODE="system" ;;
        *)
            echo "[ERROR] Unknown argument: $arg"
            echo "Usage: $0 [--user | --system]"
            exit 1
            ;;
    esac
done

if [ -z "$MODE" ]; then
    if sudo -n true 2>/dev/null || [ "$(id -u)" -eq 0 ]; then
        MODE="system"
    else
        MODE="user"
        echo "[INFO] No passwordless sudo available — installing for current user only."
        echo "       Run with --system (and enter your password) for system-wide install."
    fi
fi

# ---------------------------------------------------------------------------
# SYSTEM-WIDE INSTALL
# ---------------------------------------------------------------------------
do_system_install() {
    DEST_BIN="/usr/local/bin"
    DEST_LIB="/usr/local/lib"

    echo "[INFO] Installing dwc system-wide to $DEST_BIN ..."

    sudo mkdir -p "$DEST_BIN" "$DEST_LIB"

    sudo cp -f "$DWC_BIN" "$DEST_BIN/dwc"
    sudo chmod 755 "$DEST_BIN/dwc"

    sudo cp -f "$DYLIB" "$DEST_LIB/libVCPLibrary.dylib"
    sudo chmod 755 "$DEST_LIB/libVCPLibrary.dylib"

    # Fix RPATH: the binary was built with @executable_path; after moving to
    # /usr/local/bin the dylib must be found in /usr/local/lib instead.
    sudo install_name_tool -rpath @executable_path "$DEST_LIB" "$DEST_BIN/dwc"

    # Re-sign after RPATH modification (required on macOS 12+).
    sudo codesign --force --sign - "$DEST_BIN/dwc"

    echo ""
    echo "============================================================"
    echo "  SUCCESS: dwc has been installed to $DEST_BIN"
    echo "  Open a new terminal and run:"
    echo "    dwc --help"
    echo "============================================================"
}

# ---------------------------------------------------------------------------
# USER-LEVEL INSTALL (PATH extension)
# ---------------------------------------------------------------------------
add_path_to_rc() {
    RC_FILE="$1"
    # Create the file if it does not exist so the PATH entry is always written.
    [ -f "$RC_FILE" ] || touch "$RC_FILE" || return 0

    if grep -qF "$SCRIPT_DIR" "$RC_FILE" 2>/dev/null; then
        echo "[OK] '$RC_FILE' already references '$SCRIPT_DIR'."
        return 0
    fi

    printf '\n# dwc display control CLI\nexport PATH="%s:$PATH"\n' "$SCRIPT_DIR" >> "$RC_FILE"
    echo "[OK] Added '$SCRIPT_DIR' to PATH in $RC_FILE."
}

do_user_install() {
    echo "[INFO] Installing dwc for current user ..."

    add_path_to_rc "$HOME/.zshrc"
    add_path_to_rc "$HOME/.bash_profile"

    # Export PATH in the current session so the user can run dwc immediately
    # in this Terminal window without reopening a new one.
    export PATH="$SCRIPT_DIR:$PATH"

    echo ""
    echo "============================================================"
    echo "  SUCCESS: dwc has been installed for the current user."
    echo ""
    echo "  dwc is ready to use in THIS window right now."
    echo "  For new terminal windows it will also be available"
    echo "  automatically (PATH was written to ~/.zshrc)."
    echo ""
    echo "  Verify:"
    echo "    dwc --help"
    echo ""
    echo "  NOTE: Do not move this folder after installation."
    echo "  The PATH entry points to: $SCRIPT_DIR"
    echo "============================================================"
}

case "$MODE" in
    system) do_system_install ;;
    user)   do_user_install ;;
esac

printf "\nPress Enter to close this window..."
read -r _
